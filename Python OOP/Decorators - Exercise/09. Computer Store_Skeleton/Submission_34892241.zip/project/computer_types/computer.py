class Computer:
    def __init__(self, manufacturer, model):
        if not manufacturer or manufacturer.isspace():
            raise ValueError("Manufacturer name cannot be empty.")
        if not model or model.isspace():
            raise ValueError("Model name cannot be empty.")

        self.manufacturer = manufacturer
        self.model = model
        self.processor = None
        self.ram = None
        self.price = 0

    def configure_computer(self, processor, ram):
        self.processor = processor
        self.ram = ram

    def __repr__(self):
        return f"{self.manufacturer} {self.model} with {self.processor} and {self.ram}GB RAM"

